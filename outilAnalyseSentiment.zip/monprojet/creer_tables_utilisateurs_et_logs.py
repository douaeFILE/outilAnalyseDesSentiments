import mysql.connector

# Connexion à MySQL sans mot de passe (XAMPP par défaut)
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",  # Aucun mot de passe
    database="sentiment_analyse"
)

cursor = conn.cursor()

# Création de la table users
cursor.execute("""
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255)
)
""")

# Création de la table user_logs
cursor.execute("""
CREATE TABLE IF NOT EXISTS user_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_email VARCHAR(100),
    choix VARCHAR(50),
    date_action TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
""")

print("✅ Tables 'users' et 'user_logs' créées avec succès.")
cursor.close()
conn.close()

