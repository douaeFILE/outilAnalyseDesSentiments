import sys
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from googletrans import Translator

def analyze_sentiment(text_fr):
    try:
        # Traduction FR -> EN
        translator = Translator()
        traduction = translator.translate(text_fr, src='fr', dest='en')
        text_en = traduction.text

        # Analyse sentiment avec VADER
        analyzer = SentimentIntensityAnalyzer()
        score = analyzer.polarity_scores(text_en)

        # Classification basée sur score['compound']
        if score['compound'] >= 0.05:
            return "positif"
        elif score['compound'] <= -0.05:
            return "negatif"
        else:
            return "neutre"

    except Exception as e:
        print("neutre")  # Valeur par défaut si erreur
        sys.exit()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("neutre")
        sys.exit()
    
    texte_fr = sys.argv[1]
    texte_fr = texte_fr.strip()
    print(analyze_sentiment(texte_fr))
