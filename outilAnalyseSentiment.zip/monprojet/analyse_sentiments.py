import mysql.connector
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# Connexion à la base MySQL
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="sentiment_analyse"
)

cursor = conn.cursor()
analyzer = SentimentIntensityAnalyzer()

# Fonction d'analyse VADER
def analyser_sentiment(texte):
    score = analyzer.polarity_scores(texte)
    if score['compound'] >= 0.05:
        return "positif"
    elif score['compound'] <= -0.05:
        return "négatif"
    else:
        return "neutre"

# Fonction pour analyser les tweets d'une table et mettre à jour la colonne "sentiment"
def analyser_table(nom_table):
    print(f"🔍 Analyse des tweets dans {nom_table}...")
    
    # Lire tous les tweets
    cursor.execute(f"SELECT id, text FROM {nom_table}")
    rows = cursor.fetchall()
    
    for row in rows:
        id = row[0]
        texte = row[1]
        sentiment = analyser_sentiment(texte)
        
        # Mettre à jour la colonne sentiment
        cursor.execute(
            f"UPDATE {nom_table} SET sentiment = %s WHERE id = %s",
            (sentiment, id)
        )
    
    conn.commit()
    print(f"✅ Analyse terminée pour {nom_table}.")

# Appliquer aux 3 tables
analyser_table("hamas2")
analyser_table("israel2")
analyser_table("conflit2")

# Fermer la connexion
cursor.close()
conn.close()

print("🎉 Tous les tweets ont été analysés et les sentiments enregistrés.")
