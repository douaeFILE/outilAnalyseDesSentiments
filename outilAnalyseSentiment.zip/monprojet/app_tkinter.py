import tkinter as tk
from tkinter import messagebox, StringVar
from PIL import Image, ImageTk
import mysql.connector
import bcrypt
import webbrowser
import threading
import time
import winsound
import os
import pygame

# Connexion à la base de données
def connect_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="sentiment_analyse",
        port=3306
    )

user_email = None

# Animation de chargement
def loading_animation(callback):
    loading = tk.Toplevel(root)
    loading.geometry("300x100")
    loading.title("Chargement")
    tk.Label(loading, text="Chargement...", font=("Arial", 16)).pack(pady=30)
    root.update()
    winsound.MessageBeep()
    time.sleep(1.5)
    loading.destroy()
    callback()

# Page d'accueil
def accueil():
    for widget in root.winfo_children():
        widget.destroy()

    try:
        pygame.mixer.init()
        pygame.mixer.music.load("audio/intro.mp3")
        pygame.mixer.music.play()
    except Exception as e:
        print("Erreur audio :", e)

    bg_image = Image.open("image/image1.png").resize((1000, 600))
    bg = ImageTk.PhotoImage(bg_image)

    canvas = tk.Canvas(root, width=1000, height=600, highlightthickness=0)
    canvas.pack(fill="both", expand=True)
    canvas.create_image(0, 0, image=bg, anchor="nw")
    canvas.image = bg

    canvas.create_text(502, 50, text="Bienvenue dans l'Analyseur de Sentiments", font=("Arial", 24, "bold"), fill="black")

    style = {"font": ("Arial", 14, "bold"), "bg": "#2196F3", "fg": "black", "bd": 3, "relief": "ridge", "width": 15, "height": 2}

    tk.Button(root, text="🔐 LOGIN", command=lambda: threading.Thread(target=lambda: loading_animation(login_page)).start(), **style).place(x=150, y=200)
    tk.Button(root, text="📜 SIGN UP", command=lambda: threading.Thread(target=lambda: loading_animation(signup_page)).start(), **style).place(x=150, y=280)
    tk.Button(root, text="❌ EXIT", command=root.quit, font=("Arial", 12, "bold"), bg="yellow", fg="black", width=10).place(x=860, y=20)

# Page de connexion
def login_page():
    for widget in root.winfo_children():
        widget.destroy()

    bg_image = Image.open("image/image2.png").resize((1000, 600))
    bg = ImageTk.PhotoImage(bg_image)

    canvas = tk.Canvas(root, width=1000, height=600)
    canvas.pack(fill="both", expand=True)
    canvas.create_image(0, 0, image=bg, anchor="nw")
    canvas.image = bg

    email_var = StringVar()
    password_var = StringVar()
    show_password = tk.BooleanVar()

    def toggle_password():
        password_entry.config(show="" if show_password.get() else "*")

    def login():
        global user_email
        email = email_var.get()
        password = password_var.get()

        if not email or not password:
            messagebox.showerror("Erreur", "Tous les champs doivent être remplis.")
            return

        conn = connect_db()
        cursor = conn.cursor()
        cursor.execute("SELECT password FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()

        if user and bcrypt.checkpw(password.encode('utf-8'), user[0].encode('utf-8')):
            user_email = email
            with open("C:/xampp/htdocs/monprojet/app_php/session_user.txt", "w") as f:
                f.write(user_email)
            cursor.execute("INSERT INTO user_logs (user_email, choix) VALUES (%s, %s)", (email, "connexion"))
            conn.commit()
            messagebox.showinfo("Succès", "Connexion réussie !")
            choix_page()
        else:
            messagebox.showerror("Erreur", "Email ou mot de passe incorrect.")

        cursor.close()
        conn.close()

    entry_style = {"font": ("Arial", 14), "bg": "#D6EAF8", "fg": "black", "width": 30, "bd": 2, "relief": "groove"}

    tk.Entry(root, textvariable=email_var, **entry_style).place(x=320, y=140, height=35)
    password_entry = tk.Entry(root, textvariable=password_var, show="*", **entry_style)
    password_entry.place(x=320, y=310, height=35)

    tk.Checkbutton(root, text="Afficher le mot de passe", variable=show_password, command=toggle_password).place(x=320, y=390)
    tk.Button(root, text="LOGIN", command=login, bg="yellow", width=15, height=2, font=("Arial", 12, "bold")).place(x=430, y=500)
    tk.Button(root, text="EXIT", command=accueil, bg="yellow", width=10, font=("Arial", 12, "bold")).place(x=860, y=20)

# Page d'inscription
def signup_page():
    for widget in root.winfo_children():
        widget.destroy()

    bg_image = Image.open("image/image3.png").resize((1000, 600))
    bg = ImageTk.PhotoImage(bg_image)

    canvas = tk.Canvas(root, width=1000, height=600)
    canvas.pack(fill="both", expand=True)
    canvas.create_image(0, 0, image=bg, anchor="nw")
    canvas.image = bg

    username_var = StringVar()
    email_var = StringVar()
    password_var = StringVar()
    show_password = tk.BooleanVar()

    def toggle_password():
        password_entry.config(show="" if show_password.get() else "*")

    def signup():
        global user_email
        username = username_var.get()
        email = email_var.get()
        password = password_var.get()

        if not username or not email or not password:
            messagebox.showerror("Erreur", "Tous les champs doivent être remplis.")
            return

        if len(password) < 6:
            messagebox.showerror("Erreur", "Mot de passe trop court.")
            return

        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

        conn = connect_db()
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO users (username, email, password) VALUES (%s, %s, %s)", (username, email, hashed_password))
            conn.commit()
            user_email = email
            with open("C:/xampp/htdocs/monprojet/app_php/session_user.txt", "w") as f:
                f.write(user_email)
            messagebox.showinfo("Succès", "Inscription réussie !")
            choix_page()
        except mysql.connector.Error as err:
            messagebox.showerror("Erreur", f"Erreur MySQL : {err}")
        finally:
            cursor.close()
            conn.close()

    style = {"font": ("Arial", 14), "bg": "#E8F8F5", "fg": "black", "width": 30, "bd": 2, "relief": "groove"}

    tk.Entry(root, textvariable=username_var, **style).place(x=320, y=110, height=40)
    tk.Entry(root, textvariable=email_var, **style).place(x=320, y=260, height=40)
    password_entry = tk.Entry(root, textvariable=password_var, show="*", **style)
    password_entry.place(x=320, y=430, height=40)

    tk.Checkbutton(root, text="Afficher le mot de passe", variable=show_password, command=toggle_password).place(x=320, y=480)
    tk.Button(root, text="SIGN UP", command=signup, bg="yellow", width=15, height=2, font=("Arial", 12, "bold")).place(x=430, y=540)
    tk.Button(root, text="EXIT", command=accueil, bg="yellow", width=10, font=("Arial", 12, "bold")).place(x=860, y=20)

# Page de choix après connexion
def choix_page():
    for widget in root.winfo_children():
        widget.destroy()

    bg_image = Image.open("image/image4.png").resize((1000, 600))
    bg = ImageTk.PhotoImage(bg_image)

    canvas = tk.Canvas(root, width=1000, height=600)
    canvas.pack(fill="both", expand=True)
    canvas.create_image(0, 0, image=bg, anchor="nw")
    canvas.image = bg

    canvas.create_text(500, 60, text="Choisissez une source à analyser", font=("Arial", 22, "bold"), fill="white")

    def open_php(table):
        if user_email:
            conn = connect_db()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO user_logs (user_email, choix) VALUES (%s, %s)", (user_email, table))
            conn.commit()
            cursor.close()
            conn.close()
        timestamp = int(time.time())
        webbrowser.open(f"http://localhost/monprojet/app_php/sentiment_results.php?table={table}&v={timestamp}")
        root.destroy()

    tk.Button(root, text="🟢 HAMAS", command=lambda: open_php("hamas2"), font=("Arial", 12, "bold"), bg="green", fg="white", width=15).place(x=170, y=450)
    tk.Button(root, text="🔴 ISRAEL", command=lambda: open_php("israel2"), font=("Arial", 12, "bold"), bg="red", fg="white", width=15).place(x=420, y=450)
    tk.Button(root, text="🔵 CONFLIT", command=lambda: open_php("conflit2"), font=("Arial", 12, "bold"), bg="blue", fg="white", width=15).place(x=670, y=450)

    tk.Button(root, text=" exit ", command=accueil, font=("Arial", 10, "bold"), bg="orange", fg="black", width=17).place(x=800, y=20)

# Lancement principal
root = tk.Tk()
root.title("Authentification & Choix")
root.geometry("1000x600")
root.resizable(False, False)
accueil()
root.mainloop()
