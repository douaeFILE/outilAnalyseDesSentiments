import mysql.connector
import csv
import os

# Chemin du dossier contenant les fichiers CSV
chemin_dossier = r"C:\xampp\htdocs\monprojet"

# Connexion à la base de données
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="sentiment_analyse"
)

cursor = conn.cursor()

# Fonction pour importer un fichier CSV dans une table
def importer_csv(fichier, table):
    chemin_complet = os.path.join(chemin_dossier, fichier)
    print(f"📥 Importation de {fichier} dans {table}...")

    with open(chemin_complet, mode='r', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)  # Ignorer la première ligne (en-tête)
        
        for row in reader:
            try:
                id = int(row[0])
                username = row[1]
                texte = row[2]
                likes = int(row[3])
                date = row[4]
                
                cursor.execute(
                    f"INSERT IGNORE INTO {table} (id, username, text, likes, date) VALUES (%s, %s, %s, %s, %s)",
                    (id, username, texte, likes, date)
                )
            except Exception as e:
                print(f"❌ Erreur dans la ligne {row}: {e}")
    
    conn.commit()
    print(f"✅ Données importées dans {table} avec succès.")

# Importer les trois fichiers
importer_csv("israel1_export.csv", "israel1")
importer_csv("hamas1_export.csv", "hamas1")
importer_csv("conflit1_export.csv", "conflit1")

# Fermer la connexion
cursor.close()
conn.close()
print("🎉 Importation terminée.")
