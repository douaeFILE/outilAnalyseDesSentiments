import mysql.connector
import bcrypt

# Fonction pour hasher un mot de passe
def hash_password(password):
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

# Connexion MySQL sans mot de passe (XAMPP par défaut)
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",  # Aucun mot de passe
    database="sentiment_analyse"
)

cursor = conn.cursor()

# Données des utilisateurs à insérer
utilisateurs = [
    ("Douae", "douae.laayouni@etu.uae.ac.ma", "douae2020"),
    ("Oumaima", "oumaima.ihrissane@etu.uae.ac.ma", "oumaima2030")
]

# Insertion avec hash
for username, email, motdepasse in utilisateurs:
    hashed = hash_password(motdepasse)
    try:
        cursor.execute(
            "INSERT INTO users (username, email, password) VALUES (%s, %s, %s)",
            (username, email, hashed)
        )
        print(f"✅ Utilisateur '{username}' inséré avec succès.")
    except mysql.connector.IntegrityError:
        print(f"⚠️ L'utilisateur avec l'email '{email}' existe déjà.")

conn.commit()
cursor.close()
conn.close()
print("🎉 Insertion terminée.")
