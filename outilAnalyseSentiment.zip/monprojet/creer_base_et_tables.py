import mysql.connector

# Connexion à MySQL
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password=""  # Vide si aucun mot de passe défini dans XAMPP
)

cursor = conn.cursor()

# 1. Créer la base de données
cursor.execute("CREATE DATABASE IF NOT EXISTS sentiment_analyse")
print("✅ Base de données 'sentiment_analyse' créée ou déjà existante.")

# Se connecter à la base nouvellement créée
conn.database = "sentiment_analyse"

# 2. Créer la table hamas1
cursor.execute("""
    CREATE TABLE IF NOT EXISTS hamas1 (
        id INT PRIMARY KEY,
        username VARCHAR(100),
        text TEXT,
        likes INT,
        date DATETIME
    )
""")
print("✅ Table 'hamas1' créée.")

# 3. Créer la table israel1
cursor.execute("""
    CREATE TABLE IF NOT EXISTS israel1 (
        id INT PRIMARY KEY,
        username VARCHAR(100),
        text TEXT,
        likes INT,
        date DATETIME
    )
""")
print("✅ Table 'israel1' créée.")

# 4. Créer la table conflit1
cursor.execute("""
    CREATE TABLE IF NOT EXISTS conflit1 (
        id INT PRIMARY KEY,
        username VARCHAR(100),
        text TEXT,
        likes INT,
        date DATETIME
    )
""")
print("✅ Table 'conflit1' créée.")

# Fermer la connexion
cursor.close()
conn.close()
print("🎉 Toutes les tables ont été créées avec succès.")
