<?php
include("config.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_email = trim($_POST['email']);
    $theme = $_POST['theme'];
    $texte = trim($_POST['texte']);

    // 🧠 Validation
    if (!filter_var($user_email, FILTER_VALIDATE_EMAIL)) {
        $error = "❌ L'email saisi est invalide.";
    } elseif (str_word_count($texte) < 3) {
        $error = "❌ Le commentaire doit contenir au moins 3 mots.";
    } else {
        // 🔐 Analyse de sentiment avec Python
        $result = shell_exec("python ../analyse_sentiment_comment.py " . escapeshellarg($texte));
        $sentiment = trim($result);

        if (!in_array($sentiment, ['positif', 'negatif', 'neutre'])) {
            $sentiment = 'neutre';
        }

        // 💾 Enregistrement en base
        $stmt = $conn->prepare("INSERT INTO user_comments (user_email, texte, sentiment, theme) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $user_email, $texte, $sentiment, $theme);
        $stmt->execute();
        $stmt->close();

        // ✍️ Sauvegarder l'email dans session_user.txt
        file_put_contents("session_user.txt", $user_email);

        $success = "✅ Commentaire analysé et enregistré avec succès.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>💬 Ajouter un commentaire</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
            font-family: 'Segoe UI', sans-serif;
            color: #fff;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .form-container {
            background: rgba(255, 255, 255, 0.1);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 0 25px rgba(0, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            width: 100%;
            max-width: 600px;
        }
        .form-control, .form-select {
            background-color: rgba(255, 255, 255, 0.05);
            color: #fff;
            border: 1px solid #ccc;
        }
        .form-control::placeholder {
            color: #ccc;
        }
        .btn-primary {
            background: linear-gradient(45deg, #00cc99, #0077ff);
            border: none;
            font-weight: bold;
        }
        .btn-primary:hover {
            background: linear-gradient(45deg, #00b38f, #0062cc);
        }
        .btn-custom {
            margin: 5px;
        }
        .alert {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="form-container text-white">
    <h2 class="text-center mb-4">📝 Ajouter un commentaire</h2>

    <?php if (!empty($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
    <?php if (!empty($success)) echo "<div class='alert alert-success'>$success</div>"; ?>

    <form method="POST">
        <div class="mb-3">
            <label for="email" class="form-label">📧 Votre Email</label>
            <input type="email" class="form-control" name="email" placeholder="email@example.com" required>
        </div>

        <div class="mb-3">
            <label for="theme" class="form-label">📌 Thème</label>
            <select class="form-select" name="theme" required>
                <option value="hamas">Hamas</option>
                <option value="israel">Israël</option>
                <option value="conflit">Conflit</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="texte" class="form-label">💬 Commentaire</label>
            <textarea class="form-control" name="texte" rows="5" placeholder="Tapez votre message ici..." required></textarea>
        </div>

        <button type="submit" class="btn btn-primary w-100">🚀 Analyser et Enregistrer</button>
    </form>

    <div class="text-center mt-4">
        <a href="visualiser_commentaires.php" class="btn btn-warning btn-custom">📊 Résultats</a>
        <a href="index.php" class="btn btn-light text-dark btn-custom">🏠 Accueil</a>
    </div>
</div>

</body>
</html>
