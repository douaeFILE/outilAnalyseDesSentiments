<?php
require('fpdf/fpdf.php');
include("config.php");

class PDF extends FPDF
{
    function Header()
    {
        $this->SetFont('Arial', 'B', 16);
        $this->Cell(0, 10, 'Commentaires Utilisateurs - Analyse Sentimentale', 0, 1, 'C');
        $this->Ln(10);
    }

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 9);
        $this->Cell(0, 10, 'Page '.$this->PageNo().'/{nb}', 0, 0, 'C');
    }
}

// Création du PDF
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage('L');
$pdf->SetFont('Arial', 'B', 11);

// Titres de colonnes
$pdf->Cell(60, 10, 'Email', 1, 0, 'C');
$pdf->Cell(40, 10, 'Theme', 1, 0, 'C');
$pdf->Cell(30, 10, 'Sentiment', 1, 0, 'C');
$pdf->Cell(100, 10, 'Commentaire', 1, 0, 'C');
$pdf->Cell(40, 10, 'Date Action', 1, 1, 'C');

// Données
$user_filter = $_GET['user'] ?? 'all';
$filter_clause = ($user_filter !== 'all') ? "WHERE user_email = '" . $conn->real_escape_string($user_filter) . "'" : "";

$result = $conn->query("SELECT user_email, theme, sentiment, texte, date_action FROM user_comments $filter_clause ORDER BY date_action ASC");

$pdf->SetFont('Arial', '', 10);

while ($row = $result->fetch_assoc()) {
    $pdf->Cell(60, 10, iconv('UTF-8', 'windows-1252', $row['user_email']), 1);
    $pdf->Cell(40, 10, iconv('UTF-8', 'windows-1252', ucfirst($row['theme'])), 1);
    $pdf->Cell(30, 10, iconv('UTF-8', 'windows-1252', ucfirst($row['sentiment'])), 1);

    // Commentaire multiligne
    $x = $pdf->GetX();
    $y = $pdf->GetY();
    $pdf->MultiCell(100, 10, iconv('UTF-8', 'windows-1252', $row['texte']), 1, 'L');
    $pdf->SetXY($x + 100, $y);

    $pdf->Cell(40, 10, $row['date_action'], 1, 1, 'C');
}

$pdf->Output('D', 'commentaires.pdf');
exit;
?>
