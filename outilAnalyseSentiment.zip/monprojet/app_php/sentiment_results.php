<?php
include("config.php");

$allowed_tables = ["hamas2", "israel2", "conflit2"];
$table = isset($_GET["table"]) && in_array($_GET["table"], $allowed_tables) ? $_GET["table"] : "hamas2";
$theme = ucfirst(str_replace("2", "", $table));

$check_table = $conn->query("SHOW TABLES LIKE '$table'");
if ($check_table->num_rows == 0) {
    die("❌ Erreur : La table sélectionnée n'existe pas.");
}

$sql = "SELECT DATE(date) AS date, sentiment, COUNT(*) AS count FROM $table GROUP BY DATE(date), sentiment";
$result = $conn->query($sql);
$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

$sql_pie = "SELECT sentiment, COUNT(*) AS count FROM $table GROUP BY sentiment";
$result_pie = $conn->query($sql_pie);
$pie_data = [];
$total = 0;
while ($row = $result_pie->fetch_assoc()) {
    $pie_data[] = $row;
    $total += $row['count'];
}

$stop_words = [
    "avec", "cela", "celle", "cette", "ceci", "mais", "donc", "alors", "vous", "nous", "ils", "elles",
    "entre", "ainsi", "avoir", "être", "faire", "sont", "sera", "dans", "pour", "chez", "tout", "tous",
    "sans", "plus", "moins", "comme", "parce", "leurs", "leurs", "nos", "mes", "des", "les", "une", "un",
    "de", "le", "la", "et", "du", "au", "en"
];

$word_result = $conn->query("SELECT text FROM $table");
$word_list = [];
while ($row = $word_result->fetch_assoc()) {
    $text = strtolower(strip_tags($row["text"]));
    $words = str_word_count($text, 1);
    foreach ($words as $w) {
        if (strlen($w) >= 3 && !in_array($w, $stop_words)) {
            if (!isset($word_list[$w])) $word_list[$w] = 0;
            $word_list[$w]++;
        }
    }
}
arsort($word_list);
$top_words = array_slice($word_list, 0, 50);

$top_users = [];
$sentiments = ["positif", "négatif", "neutre"];
foreach ($sentiments as $sent) {
    $stmt = $conn->prepare("SELECT username, likes FROM $table WHERE sentiment = ? ORDER BY likes DESC LIMIT 1");
    $stmt->bind_param("s", $sent);
    $stmt->execute();
    $stmt->bind_result($user, $like_count);
    if ($stmt->fetch()) {
        $top_users[$sent] = ["username" => $user, "likes" => $like_count];
    }
    $stmt->close();
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Analyse des Sentiments : <?= $theme ?></title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/wordcloud2.js/1.1.0/wordcloud2.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #000;
            color: #fff;
            font-family: Arial, sans-serif;
        }
        .tab-content {
            background: #fff;
            color: #000;
            padding: 30px;
            border-radius: 15px;
            margin-top: 20px;
        }
        .nav-tabs .nav-link.active {
            background-color: #dc3545;
            color: white;
        }
        canvas {
            max-width: 100%;
        }
        .chart-pie-wrapper {
            max-width: 500px;
            margin: 0 auto;
        }
    </style>
</head>
<body class="container py-4">

<h1 class="text-center text-danger">📊 Analyse des Sentiments : <?= $theme ?></h1>
<h4 class="text-center mb-4">Total des publications : <?= $total ?></h4>

<div class="text-center mb-4">
    <h4 class="text-warning">🏆 Top utilisateurs par sentiment (likes)</h4>
    <div class="row justify-content-center">
        <?php foreach (["positif" => "✅ Positif", "négatif" => "❌ Négatif", "neutre" => "⚪ Neutre"] as $key => $label): ?>
            <?php if (isset($top_users[$key])): ?>
                <div class="col-md-3 bg-dark text-white rounded p-3 m-2">
                    <h5><?= $label ?></h5>
                    <p><strong><?= $top_users[$key]["username"] ?></strong></p>
                    <p>👍 Likes : <?= $top_users[$key]["likes"] ?></p>
                </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
</div>

<ul class="nav nav-tabs" role="tablist">
    <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#line">📈 Courbe</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#bar">📊 Barres</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#pie">🥰 Camembert</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#wordcloud">☁️ Nuage</button></li>
</ul>

<div class="tab-content">
    <div class="tab-pane fade show active" id="line"><canvas id="lineChart"></canvas></div>
    <div class="tab-pane fade" id="bar"><canvas id="barChart"></canvas></div>
    <div class="tab-pane fade" id="pie">
        <div class="chart-pie-wrapper">
            <canvas id="pieChart"></canvas>
        </div>
    </div>
    <div class="tab-pane fade" id="wordcloud"><canvas id="wordcloudCanvas" width="600" height="400"></canvas></div>
</div>

<div class="text-center mt-4">
    <button class="btn btn-success mx-2" onclick="window.location.href='admin_dashboard.php'">📋 Admin</button>
    <button class="btn btn-warning mx-2" onclick="window.location.href='index.php'">🏠 Accueil</button>
    <button class="btn btn-info mx-2" onclick="location.reload()">🔁 Actualiser</button>
</div>

<script>
    const data = <?= json_encode($data); ?>;
    const pieData = <?= json_encode($pie_data); ?>;
    const topWords = <?= json_encode($top_words); ?>;

    const dates = [...new Set(data.map(d => d.date))];
    const sentiments = ["positif", "négatif", "neutre"];
    const colors = { positif: "green", négatif: "red", neutre: "gray" };

    const datasets = sentiments.map(sentiment => ({
        label: sentiment,
        data: dates.map(date => {
            const entry = data.find(d => d.date === date && d.sentiment === sentiment);
            return entry ? entry.count : 0;
        }),
        borderColor: colors[sentiment],
        backgroundColor: colors[sentiment],
        fill: false
    }));

    new Chart("lineChart", {
        type: "line",
        data: { labels: dates, datasets },
        options: { plugins: { title: { display: true, text: "Évolution des sentiments" } } }
    });

    new Chart("barChart", {
        type: "bar",
        data: {
            labels: sentiments,
            datasets: [{
                label: "Nombre de sentiments",
                data: sentiments.map(s => pieData.find(d => d.sentiment === s)?.count || 0),
                backgroundColor: sentiments.map(s => colors[s])
            }]
        },
        options: { plugins: { title: { display: true, text: "Répartition des sentiments" } } }
    });

    new Chart("pieChart", {
        type: "pie",
        data: {
            labels: pieData.map(d => d.sentiment),
            datasets: [{
                data: pieData.map(d => d.count),
                backgroundColor: pieData.map(d => colors[d.sentiment])
            }]
        },
        options: { plugins: { title: { display: true, text: "Diagramme circulaire des sentiments" } } }
    });

    const wordList = Object.entries(topWords).map(([w, c]) => [w, c]);
    const canvas = document.getElementById('wordcloudCanvas');
    let cloudDrawn = false;

    document.querySelector('button[data-bs-target="#wordcloud"]').addEventListener('click', () => {
        if (!cloudDrawn) {
            WordCloud(canvas, {
                list: wordList,
                gridSize: 10,
                weightFactor: 5,
                backgroundColor: "transparent",
                color: 'random-dark'
            });
            cloudDrawn = true;
        }
    });
</script>

</body>
</html>
