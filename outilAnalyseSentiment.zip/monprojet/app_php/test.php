<?php
echo "✅ PHP fonctionne bien !<br>";

include("config.php"); // Doit être dans le même dossier ou donne le bon chemin

$sql = "SELECT * FROM hamas2 LIMIT 1";
$result = $conn->query($sql);

if ($result) {
    echo "✅ Connexion MySQL réussie !";
} else {
    echo "❌ Erreur de requête : " . $conn->error;
}
?>