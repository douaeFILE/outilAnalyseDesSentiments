<?php
// Configuration de la base de données MySQL (XAMPP)
$servername = "localhost";
$username = "root";
$password = ""; // Aucun mot de passe par défaut sur XAMPP
$dbname = "sentiment_analyse";
$port = 3306;

// Connexion à la base de données
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Vérification de la connexion
if ($conn->connect_error) {
    die("❌ Connexion échouée : " . $conn->connect_error);
}

// Assurer que l'encodage est UTF-8 pour les accents/français
$conn->set_charset("utf8");
?>