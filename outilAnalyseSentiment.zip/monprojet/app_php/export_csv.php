<?php
include("config.php");

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=commentaires.csv');

$output = fopen("php://output", "w");

// 📝 En-têtes du fichier CSV
fputcsv($output, ['ID', 'Email', 'Texte', 'Sentiment', 'Thème', 'Date d\'ajout']);

// 📋 Filtrage par utilisateur si demandé
$user_filter = $_GET['user'] ?? 'all';
$filter_clause = ($user_filter !== 'all') ? "WHERE user_email = '" . $conn->real_escape_string($user_filter) . "'" : "";

// 🗃️ Sélection des colonnes à exporter
$sql = "SELECT id, user_email, texte, sentiment, theme, date_action FROM user_comments $filter_clause ORDER BY date_action ASC";
$result = $conn->query($sql);

// 🖊️ Écriture des lignes dans le fichier CSV
while ($row = $result->fetch_assoc()) {
    fputcsv($output, [
        $row['id'],
        $row['user_email'],
        $row['texte'],
        $row['sentiment'],
        $row['theme'],
        $row['date_action']  // Correction ici !!
    ]);
}

fclose($output);
exit;
?>

