<?php
include("config.php");
header('Content-Type: text/html; charset=utf-8');

if (isset($_GET['all']) && $_GET['all'] == '1') {
    file_put_contents("session_user.txt", "all");
    $user_filter = 'all';
} else {
    $user_filter = file_exists("session_user.txt") ? trim(file_get_contents("session_user.txt")) : 'all';
}
$filter_clause = ($user_filter !== 'all') ? "WHERE user_email = '" . $conn->real_escape_string($user_filter) . "'" : "";

$sql = "SELECT theme, sentiment, COUNT(*) as count FROM user_comments $filter_clause GROUP BY theme, sentiment";
$result = $conn->query($sql);
$data = ["hamas" => [], "israel" => [], "conflit" => []];
$sentiments = ["positif", "negatif", "neutre"];
foreach ($sentiments as $s) {
    foreach (["hamas", "israel", "conflit"] as $t) {
        $data[$t][$s] = 0;
    }
}
while ($row = $result->fetch_assoc()) {
    $data[$row['theme']][$row['sentiment']] = (int)$row['count'];
}

$words = [];
$comments = ["positif" => [], "negatif" => [], "neutre" => []];
$stop_words = ["avec", "cela", "celle", "cette", "ceci", "mais", "donc", "alors", "vous", "nous", "ils", "elles", "entre", "ainsi", "avoir", "être", "faire", "sont", "sera", "dans", "pour", "chez", "tout", "tous", "sans", "plus", "moins", "comme", "parce", "leurs", "nos", "mes", "des", "les", "une", "un", "de", "le", "la", "et", "du", "au", "en"];

$word_result = $conn->query("SELECT texte, sentiment FROM user_comments $filter_clause");
while ($row = $word_result->fetch_assoc()) {
    $text = strtolower(strip_tags($row["texte"]));
    $comments[$row['sentiment']][] = $row["texte"];
    $words_arr = str_word_count($text, 1);
    foreach ($words_arr as $w) {
        if (strlen($w) >= 3 && !in_array($w, $stop_words)) {
            if (!isset($words[$w])) $words[$w] = 0;
            $words[$w]++;
        }
    }
}
arsort($words);
$top_words = array_slice($words, 0, 50);

$evolution_data = [];
if ($user_filter === 'all') {
    $evolution_sql = "SELECT DATE(date_action) as date, COUNT(*) as total FROM user_comments GROUP BY DATE(date_action) ORDER BY DATE(date_action)";
    $evolution_result = $conn->query($evolution_sql);
    while ($row = $evolution_result->fetch_assoc()) {
        $evolution_data[$row['date']] = (int)$row['total'];
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<title>Visualisation des Commentaires</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/wordcloud2.js/1.1.0/wordcloud2.min.js"></script>
<style>
body { background: #f2f2f2; min-height: 100vh; color: #333; padding: 30px; font-family: 'Segoe UI', sans-serif; }
h1 { text-align: center; margin-bottom: 30px; }
.nav-tabs .nav-link.active { background-color: #0d6efd; color: #fff; border-radius: 10px; }
.container { background: #fff; padding: 40px; border-radius: 20px; box-shadow: 0 0 25px rgba(0,0,0,0.2); }
canvas { margin: 20px auto; display: block; background: #fff; padding: 10px; border-radius: 10px; height: 400px !important; }
.comment-section { margin-top: 40px; background: #e9ecef; padding: 30px; border-radius: 15px; }
.btn { margin: 5px; border-radius: 10px; }
ul { list-style: none; padding: 0; }
li { background: #f8f9fa; margin: 5px 0; padding: 10px; border-radius: 10px; }
</style>
</head>

<body>
<h1>📊 Résultats pour : <?= htmlspecialchars($user_filter) ?></h1>

<ul class="nav nav-tabs justify-content-center">
    <?php if ($user_filter === 'all'): ?>
        <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#courbe">📈 Courbe</button></li>
    <?php else: ?>
        <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#bar">📊 Barres</button></li>
    <?php endif; ?>
    <li class="nav-item"><button class="nav-link <?= ($user_filter !== 'all') ? '' : 'active' ?>" data-bs-toggle="tab" data-bs-target="#camembert">🥰 Camembert</button></li>
    <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#nuage">☁️ Nuage</button></li>
</ul>

<div class="tab-content container">
    <?php if ($user_filter === 'all'): ?>
        <div class="tab-pane fade show active" id="courbe"><canvas id="evolutionChart"></canvas></div>
    <?php else: ?>
        <div class="tab-pane fade show active" id="bar"><canvas id="barChart"></canvas></div>
    <?php endif; ?>
    <div class="tab-pane fade <?= ($user_filter !== 'all') ? 'show active' : '' ?>" id="camembert"><canvas id="pieChart" width="400" height="400"></canvas></div>
    <div class="tab-pane fade" id="nuage"><canvas id="wordCloudCanvas" width="1000" height="600"></canvas></div>
</div>

<div class="container comment-section">
<h3 class="text-center">📄 Commentaires classés par sentiment</h3>
<?php foreach ($comments as $type => $list): ?>
<h5 style="color: <?= $type==='positif'?'green':($type==='negatif'?'red':'gray') ?>;"> <?= ucfirst($type) ?> (<?= count($list) ?>) </h5>
<ul><?php foreach ($list as $c): ?><li><?= htmlspecialchars($c) ?></li><?php endforeach; ?></ul>
<?php endforeach; ?>
</div>

<div class="text-center mt-4">
<a href="index.php" class="btn btn-warning">🏠 Accueil</a>
<a href="comment_form.php" class="btn btn-info">💬 Ajouter commentaire</a>
<a href="visualiser_commentaires.php?all=1" class="btn btn-primary">🌍 Tous les utilisateurs</a>
<a href="export_csv.php?user=<?= urlencode($user_filter) ?>" class="btn btn-success">📄 Exporter CSV</a>
<a href="export_pdf.php?user=<?= urlencode($user_filter) ?>" class="btn btn-danger" target="_blank">🧾 Exporter PDF</a>
</div>

<script>
const data = <?= json_encode($data); ?>;
const topWords = <?= json_encode($top_words); ?>;
const sentiments = ["positif", "negatif", "neutre"];
const colors = { positif: "#28a745", negatif: "#dc3545", neutre: "#6c757d" };

window.onload = function () {
    <?php if ($user_filter !== 'all'): ?>
    new Chart(document.getElementById("barChart"), {
        type: "bar",
        data: {
            labels: ["Hamas", "Israël", "Conflit"],
            datasets: sentiments.map(s => ({
                label: s,
                data: [data.hamas[s], data.israel[s], data.conflit[s]],
                backgroundColor: colors[s]
            }))
        },
        options: {
            responsive: true,
            plugins: {
                title: { display: true, text: 'Répartition des sentiments par thème', color: '#333', font: {size: 18} },
                legend: { labels: {color: '#333'} }
            },
            scales: {
                x: { ticks: { color: '#333' } },
                y: { ticks: { color: '#333' } }
            }
        }
    });
    <?php endif; ?>

    new Chart(document.getElementById("pieChart"), {
        type: "pie",
        data: {
            labels: sentiments,
            datasets: [{
                data: sentiments.map(s => data.hamas[s] + data.israel[s] + data.conflit[s]),
                backgroundColor: sentiments.map(s => colors[s])
            }]
        },
        options: {
            responsive: false,
            plugins: {
                title: { display: true, text: 'Répartition globale des sentiments', color: '#333', font: {size: 18} },
                legend: { position: 'top', labels: { color: '#333' } }
            }
        }
    });

    WordCloud(document.getElementById("wordCloudCanvas"), {
        list: Object.entries(topWords),
        gridSize: 20,
        weightFactor: 12,
        backgroundColor: "#fff",
        color: "random-dark"
    });

    <?php if ($user_filter === 'all' && !empty($evolution_data)): ?>
    new Chart(document.getElementById("evolutionChart"), {
        type: "line",
        data: {
            labels: <?= json_encode(array_keys($evolution_data)); ?>,
            datasets: [{
                label: "Commentaires par date",
                data: <?= json_encode(array_values($evolution_data)); ?>,
                borderColor: "#0dcaf0",
                backgroundColor: "#0dcaf0",
                tension: 0.4,
                fill: false
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: { display: true, text: "Évolution du nombre de commentaires", color: '#333', font: {size: 18} },
                legend: { labels: { color: '#333' } }
            },
            scales: {
                x: { ticks: { color: '#333' } },
                y: { ticks: { color: '#333' } }
            }
        }
    });
    <?php endif; ?>
};
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
