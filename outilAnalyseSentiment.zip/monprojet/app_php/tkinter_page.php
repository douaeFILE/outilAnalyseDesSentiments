<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>Retour vers Tkinter</title>
    <style>
        body {
            background-color: #1c1c1c;
            color: white;
            font-family: Arial, sans-serif;
            text-align: center;
            padding-top: 100px;
        }

        h2 {
            color: #00ccff;
            margin-bottom: 30px;
        }

        .btn {
            padding: 12px 25px;
            font-size: 16px;
            background-color: #00cc66;
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #00994d;
        }

        .icon {
            font-size: 40px;
            color: #00ccff;
            margin-bottom: 20px;
        }
    </style>
</head>

<body>
    <div class="icon">🔁</div>
    <h2>Vous pouvez maintenant fermer cette page<br>et revenir à l'application Tkinter.</h2>
    <button class="btn" onclick="window.close()">❌ Fermer cette page</button>
</body>

</html>