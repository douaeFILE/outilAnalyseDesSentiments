<?php
session_start();
include("config.php");

// Lire l'email de l'utilisateur depuis le fichier session_user.txt
$emailActuel = '';
$sessionFile = "session_user.txt"; // Le fichier où l'email est stocké
if (file_exists($sessionFile)) {
    $emailActuel = trim(file_get_contents($sessionFile)); // Lire l'email dans le fichier
    $_SESSION['email'] = $emailActuel; // Sauvegarder l'email dans la session
}

// Vérifier si l'utilisateur est connecté
if (empty($emailActuel)) {
    echo "❌ Vous devez être connecté pour accéder à cette page.";
    exit();
}

// Supprimer l'historique personnel
if (isset($_POST['delete_mine']) && !empty($emailActuel)) {
    $stmt = $conn->prepare("DELETE FROM user_logs WHERE user_email = ?");
    $stmt->bind_param("s", $emailActuel);
    $stmt->execute();
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Afficher l'historique de l'utilisateur connecté
$sql = "SELECT user_email, choix, date_action FROM user_logs WHERE user_email = ? ORDER BY date_action DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $emailActuel);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Panneau Admin - Logs Utilisateurs</title>
    <style>
        body {
            background-color: #121212;
            color: white;
            font-family: Arial;
            text-align: center;
        }

        h1 {
            color: #00cc99;
            margin-top: 30px;
        }

        table {
            margin: auto;
            border-collapse: collapse;
            width: 85%;
            background-color: white;
            color: black;
            margin-top: 30px;
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            border: 1px solid #888;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #00cc99;
            color: white;
        }

        .buttons {
            margin-top: 40px;
        }

        .buttons button {
            padding: 12px 20px;
            font-size: 16px;
            margin: 10px;
            border-radius: 10px;
            cursor: pointer;
            border: none;
        }

        .return-btn { background-color: #0066ff; color: white; }
        .exit-btn { background-color: #ff3333; color: white; }
        .home-btn { background-color: orange; color: white; }
        .delete-btn { background-color: #cc0000; color: white; }
    </style>
</head>

<body>
<h1>📊 Historique des Recherches</h1>

<?php if ($result->num_rows > 0): ?>
    <table>
        <tr>
            <th>Email</th>
            <th>Choix</th>
            <th>Date</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['user_email']) ?></td>
                <td><?= htmlspecialchars($row['choix']) ?></td>
                <td><?= htmlspecialchars($row['date_action']) ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
<?php else: ?>
    <p>Aucune recherche n'a encore été enregistrée.</p>
<?php endif; ?>

<div class="buttons">
    <button class="return-btn" onclick="window.location.href='sentiment_results.php'">↩️ Retour Résultats</button>
    <button class="home-btn" onclick="window.location.href='index.php'">🏡 Accueil Web</button>

    <form method="post" style="display:inline;">
        <button type="submit" name="delete_mine" class="delete-btn" onclick="return confirm('Supprimer uniquement votre historique ?');">
            🧹 Supprimer mon historique
        </button>
    </form>

    <button class="exit-btn" onclick="window.close()">❌ Quitter</button>
</div>

<?php $conn->close(); ?>
</body>
</html>
