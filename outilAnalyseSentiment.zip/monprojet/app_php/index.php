<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Accueil - Analyse des Sentiments</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: url("/monprojet/image/aksa.jpg") no-repeat center center fixed;
      background-size: cover;
      color: white;
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .card-container {
      background-color: rgba(0, 0, 0, 0.7);
      padding: 40px;
      border-radius: 20px;
      box-shadow: 0 0 25px rgba(0, 255, 255, 0.4);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      width: 100%;
      max-width: 600px;
      text-align: center;
    }

    h1 {
      color: #00ccff;
      margin-bottom: 40px;
      font-weight: bold;
      text-shadow: 1px 1px 5px black;
    }

    .btn-custom {
      display: block;
      width: 100%;
      margin-bottom: 15px;
      font-size: 18px;
      padding: 12px;
      border-radius: 12px;
      font-weight: bold;
      border: none;
      transition: 0.3s ease-in-out;
    }

    .btn-hamas { background-color: #198754; color: white; }
    .btn-israel { background-color: #dc3545; color: white; }
    .btn-conflit { background-color: #0d6efd; color: white; }
    .btn-comment { background-color: #17a2b8; color: white; }
    .btn-admin { background-color: #fd7e14; color: white; }
    .btn-danger { background-color: #6c757d; color: white; }

    .btn-custom:hover {
      transform: scale(1.05);
      opacity: 0.9;
    }
  </style>
</head>
<body>
  <div class="card-container">
    <h1>📊 Bienvenue dans l'application d'analyse des sentiments</h1>

    <a href="sentiment_results.php?table=hamas2" class="btn btn-custom btn-hamas">🟢 Résultats HAMAS</a>
    <a href="sentiment_results.php?table=israel2" class="btn btn-custom btn-israel">🔴 Résultats ISRAËL</a>
    <a href="sentiment_results.php?table=conflit2" class="btn btn-custom btn-conflit">🔵 Résultats CONFLIT</a>
    <a href="comment_form.php" class="btn btn-custom btn-comment">💬 Ajouter un commentaire</a>
    <a href="admin_dashboard.php" class="btn btn-custom btn-admin">🛠️ Panneau Admin</a>
    <button class="btn btn-custom btn-danger" onclick="quitter()">🚪 Quitter</button>
  </div>

  <script>
    function quitter() {
      const container = document.querySelector('.card-container');
      container.innerHTML = `
        <h1>👋 Vous avez quitté la page web</h1>
        <p style="margin: 20px 0;">Souhaitez-vous revenir à l'accueil ?</p>
        <a href="index.php" class="btn btn-custom btn-conflit">🏠 Retour à l'accueil</a>
      `;
    }
  </script>
</body>
</html>
