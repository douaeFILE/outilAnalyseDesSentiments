import mysql.connector

# Connexion MySQL
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="sentiment_analyse"
)

cursor = conn.cursor()

# Fonction pour créer une table "copiée" avec une colonne sentiment
def creer_table_avec_sentiment(nom_source, nom_destination):
    print(f"🔄 Création de {nom_destination} à partir de {nom_source}...")

    # Supprimer la table si elle existe déjà (optionnel)
    cursor.execute(f"DROP TABLE IF EXISTS {nom_destination}")

    # Créer la nouvelle table avec toutes les données de l'ancienne
    cursor.execute(f"""
        CREATE TABLE {nom_destination} AS
        SELECT * FROM {nom_source}
    """)

    # Ajouter la colonne "sentiment" vide
    cursor.execute(f"""
        ALTER TABLE {nom_destination}
        ADD COLUMN sentiment VARCHAR(50)
    """)

    print(f"✅ Table {nom_destination} créée avec succès avec la colonne 'sentiment'.")

# Création des 3 nouvelles tables
creer_table_avec_sentiment("hamas1", "hamas2")
creer_table_avec_sentiment("israel1", "israel2")
creer_table_avec_sentiment("conflit1", "conflit2")

# Fermer la connexion
cursor.close()
conn.close()
print("🎉 Toutes les nouvelles tables sont prêtes pour l'analyse de sentiments.")

